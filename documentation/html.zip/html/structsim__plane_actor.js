var structsim__plane_actor =
[
    [ "plane", "structsim__plane_actor.html#ad5ad5a5f8ca37263d2553ca6b722f3c7", null ],
    [ "stateLengthTimeInMs", "structsim__plane_actor.html#a0929e35cc1b6163beca80f8378199df5", null ],
    [ "stateRemainTimeInMs", "structsim__plane_actor.html#a22386bc4d8d71c973e2332bf137358a7", null ]
];