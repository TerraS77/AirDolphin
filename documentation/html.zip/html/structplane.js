var structplane =
[
    [ "matriculation", "structplane.html#ae8aba8bb7230722fd49ba94c04e281f2", null ],
    [ "passengers", "structplane.html#a51008cd12b3ac96648711b6acea0dcfc", null ],
    [ "passengersMax", "structplane.html#a8464e2e0b71d7d354e72e428a0bd46f7", null ],
    [ "status", "structplane.html#aaa46862b0bed435cc0bb408f30daa2de", null ],
    [ "targetRunway", "structplane.html#a74eaef8f104631cb505542884523a413", null ],
    [ "type", "structplane.html#ad590768c1f23be9a7ac6b5245391125a", null ]
];