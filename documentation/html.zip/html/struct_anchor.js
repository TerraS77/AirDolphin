var struct_anchor =
[
    [ "x", "struct_anchor.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "struct_anchor.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];