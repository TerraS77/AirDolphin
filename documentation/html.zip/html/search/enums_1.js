var searchData=
[
  ['planestatus_299',['planeStatus',['../_air_manager_8h.html#a4d4784741db00d82597c0ad8eed0413c',1,'AirManager.h']]],
  ['planetype_300',['planeType',['../_air_manager_8h.html#a2a01c5db75a78c5ec2a4804e65a5a28c',1,'AirManager.h']]]
];
