var searchData=
[
  ['waiting_5flanding_321',['WAITING_LANDING',['../_air_manager_8h.html#a4d4784741db00d82597c0ad8eed0413ca0975f228988aadbfa36168807d9ae12c',1,'AirManager.h']]],
  ['waiting_5ftakeoff_322',['WAITING_TAKEOFF',['../_air_manager_8h.html#a4d4784741db00d82597c0ad8eed0413ca809245b9c47b1194face905e6e3b2c5d',1,'AirManager.h']]]
];
