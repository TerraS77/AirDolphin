var searchData=
[
  ['emptylist_41',['emptyList',['../_smart_list_8c.html#acdb91fb9f89f4a82b263df07e7af207e',1,'emptyList(list *list):&#160;SmartList.c'],['../_smart_list_8h.html#acdb91fb9f89f4a82b263df07e7af207e',1,'emptyList(list *list):&#160;SmartList.c']]]
];
