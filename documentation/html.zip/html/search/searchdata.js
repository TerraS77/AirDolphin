var indexSectionsWithContent =
{
  0: "abcdefgilmnoprstuwxy",
  1: "abclprs",
  2: "abcrs",
  3: "abcdegilmnoprsu",
  4: "acdfilmnprstwxy",
  5: "mprt",
  6: "abcflmprstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

