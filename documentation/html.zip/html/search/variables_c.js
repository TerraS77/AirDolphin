var searchData=
[
  ['waitforrunwayqueue_294',['waitForRunwayQueue',['../structairport.html#ab4dd1d04047c5d1e157c7888e6d5e62e',1,'airport']]],
  ['width_295',['width',['../structrunway.html#ae426f00e82704fa09578f5446e22d915',1,'runway']]]
];
