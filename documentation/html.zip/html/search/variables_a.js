var searchData=
[
  ['selected_285',['selected',['../structbutton.html#a9ee682957ef18956fbe33afe9b6222fa',1,'button']]],
  ['simulationspeedinms_286',['simulationSpeedInMs',['../structsimulation.html#a21aed27382c21bf38c675ea0570cdb80',1,'simulation']]],
  ['statelengthtimeinms_287',['stateLengthTimeInMs',['../structsim__plane_actor.html#a0929e35cc1b6163beca80f8378199df5',1,'sim_planeActor']]],
  ['stateremaintimeinms_288',['stateRemainTimeInMs',['../structsim__plane_actor.html#a22386bc4d8d71c973e2332bf137358a7',1,'sim_planeActor']]],
  ['status_289',['status',['../structplane.html#aaa46862b0bed435cc0bb408f30daa2de',1,'plane']]]
];
