var searchData=
[
  ['newairport_89',['newAirport',['../_air_manager_8c.html#a4cfbfa72ca873466a6f1f849b921b10d',1,'newAirport(unsigned int parkingSize):&#160;AirManager.c'],['../_air_manager_8h.html#a4cfbfa72ca873466a6f1f849b921b10d',1,'newAirport(unsigned int parkingSize):&#160;AirManager.c']]],
  ['newbutton_90',['newButton',['../_renderer_8c.html#a17e573bc6a972ee4c98963e3f0fac47b',1,'Renderer.c']]],
  ['newchainitem_91',['newChainItem',['../_smart_list_8c.html#af492cf3e8e1eb026f5182b19d4360c2d',1,'SmartList.c']]],
  ['newlist_92',['newList',['../_smart_list_8c.html#a0beeaf9f844e9101109c6b668288ed02',1,'newList(compareTwoPointersFunction comparatorFunction):&#160;SmartList.c'],['../_smart_list_8h.html#a0beeaf9f844e9101109c6b668288ed02',1,'newList(compareTwoPointersFunction comparatorFunction):&#160;SmartList.c']]],
  ['newplane_93',['newPlane',['../_air_manager_8c.html#aa11c020e6aa8bf76b531ac290225419b',1,'newPlane(char matriculation[7], planeType type, unsigned int passengers, unsigned int passengersMax, planeStatus status):&#160;AirManager.c'],['../_air_manager_8h.html#aa11c020e6aa8bf76b531ac290225419b',1,'newPlane(char matriculation[7], planeType type, unsigned int passengers, unsigned int passengersMax, planeStatus status):&#160;AirManager.c']]],
  ['newrunway_94',['newRunway',['../_air_manager_8c.html#a22458e84eb54f144c2bcba34b7e83258',1,'newRunway(float length, float width, runwayType type, unsigned int maxTakeoffQueue):&#160;AirManager.c'],['../_air_manager_8h.html#a22458e84eb54f144c2bcba34b7e83258',1,'newRunway(float length, float width, runwayType type, unsigned int maxTakeoffQueue):&#160;AirManager.c']]],
  ['newsimplaneactor_95',['newSimPlaneActor',['../_air_sim_8c.html#ab0797c6b480611c526f9aae5328ed9b3',1,'AirSim.c']]],
  ['next_96',['next',['../structchain_item.html#ae2a62e969319cae7cdb3c358b1d0b453',1,'chainItem']]]
];
