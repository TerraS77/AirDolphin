var searchData=
[
  ['openchainfile_97',['openChainFile',['../bdd_manager_8c.html#aed0dd657e4d047d80405144e48d33a81',1,'openChainFile(char *fileName, simulation *simulation):&#160;bddManager.c'],['../bdd_manager_8h.html#aed0dd657e4d047d80405144e48d33a81',1,'openChainFile(char *fileName, simulation *simulation):&#160;bddManager.c']]]
];
