var searchData=
[
  ['takeoffqueue_290',['takeoffQueue',['../structrunway.html#aea8d44ebe522f023744fb3dc6b02f8cf',1,'runway']]],
  ['targetrunway_291',['targetRunway',['../structplane.html#a74eaef8f104631cb505542884523a413',1,'plane']]],
  ['text_292',['text',['../structbutton.html#a5633b1433389cec21ade3811bbe9ca5b',1,'button']]],
  ['type_293',['type',['../structplane.html#ad590768c1f23be9a7ac6b5245391125a',1,'plane::type()'],['../structrunway.html#a7bdc73d22d9a03d0a92f87f54e23d67a',1,'runway::type()']]]
];
