var searchData=
[
  ['textalign_302',['textAlign',['../_renderer_8c.html#a29fe3ea9b028c9d355dc2852c709f06d',1,'Renderer.c']]]
];
