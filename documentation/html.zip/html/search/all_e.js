var searchData=
[
  ['saveplanesinfile_130',['savePlanesInFile',['../bdd_manager_8c.html#ac71ce01f34ca4b83eedd3438379a5d1d',1,'savePlanesInFile(airport *airport):&#160;bddManager.c'],['../bdd_manager_8h.html#ac71ce01f34ca4b83eedd3438379a5d1d',1,'savePlanesInFile(airport *airport):&#160;bddManager.c']]],
  ['searchdatainlist_131',['searchDataInList',['../_smart_list_8c.html#a9c4a5c280a2b3a05fe3f6e42fa22aa0e',1,'searchDataInList(list list, void *data):&#160;SmartList.c'],['../_smart_list_8h.html#a9c4a5c280a2b3a05fe3f6e42fa22aa0e',1,'searchDataInList(list list, void *data):&#160;SmartList.c']]],
  ['searchindexinlist_132',['searchIndexInList',['../_smart_list_8c.html#a54db1ab094df930f17147115a4c44e47',1,'searchIndexInList(list list, void *data):&#160;SmartList.c'],['../_smart_list_8h.html#a54db1ab094df930f17147115a4c44e47',1,'searchIndexInList(list list, void *data):&#160;SmartList.c']]],
  ['selected_133',['selected',['../structbutton.html#a9ee682957ef18956fbe33afe9b6222fa',1,'button']]],
  ['setdrawcolor_134',['SetDrawColor',['../_renderer_8c.html#abcf7919e2f7088f1b2f5a6564fb5a508',1,'Renderer.c']]],
  ['sim_5fplaneactor_135',['sim_planeActor',['../structsim__plane_actor.html',1,'']]],
  ['simulation_136',['simulation',['../structsimulation.html',1,'']]],
  ['simulationspeedinms_137',['simulationSpeedInMs',['../structsimulation.html#a21aed27382c21bf38c675ea0570cdb80',1,'simulation']]],
  ['smakechaindata_138',['sMakeChainData',['../bdd_manager_8c.html#a34ea4760e83292a1e111ef24369b3535',1,'bddManager.c']]],
  ['small_139',['SMALL',['../_air_manager_8h.html#a9e269e7cf5cb230c5aa5861d57308ce3aea5e596a553757a677cb4da4c8a1f935',1,'AirManager.h']]],
  ['smartlist_2ec_140',['SmartList.c',['../_smart_list_8c.html',1,'']]],
  ['smartlist_2eh_141',['SmartList.h',['../_smart_list_8h.html',1,'']]],
  ['statelengthtimeinms_142',['stateLengthTimeInMs',['../structsim__plane_actor.html#a0929e35cc1b6163beca80f8378199df5',1,'sim_planeActor']]],
  ['stateremaintimeinms_143',['stateRemainTimeInMs',['../structsim__plane_actor.html#a22386bc4d8d71c973e2332bf137358a7',1,'sim_planeActor']]],
  ['status_144',['status',['../structplane.html#aaa46862b0bed435cc0bb408f30daa2de',1,'plane']]]
];
