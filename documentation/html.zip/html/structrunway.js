var structrunway =
[
    [ "id", "structrunway.html#af749ccd9c242573390416d80accd7b39", null ],
    [ "length", "structrunway.html#a6150639f5295064e97e299a9206d16b1", null ],
    [ "maxTakeoffQueue", "structrunway.html#a754c85d13a1d5841aad9f10e110af947", null ],
    [ "planeLT", "structrunway.html#a292849b89f3d7d3967545ece3175931d", null ],
    [ "takeoffQueue", "structrunway.html#aea8d44ebe522f023744fb3dc6b02f8cf", null ],
    [ "type", "structrunway.html#a7bdc73d22d9a03d0a92f87f54e23d67a", null ],
    [ "width", "structrunway.html#ae426f00e82704fa09578f5446e22d915", null ]
];