var structairport =
[
    [ "landingQueue", "structairport.html#ac6ea3c10c8a44a2a4279d8a372728935", null ],
    [ "parkingPlanes", "structairport.html#a5710bad512f54923dc969c00a5f415bb", null ],
    [ "parkingSize", "structairport.html#a4e6110598cbff8f231bdd125eccf4835", null ],
    [ "planesInRange", "structairport.html#a836e885d023d205ab7d2a135d1ccc56a", null ],
    [ "runways", "structairport.html#ad68c502a4dd9d694ed3f388a42c781c7", null ],
    [ "waitForRunwayQueue", "structairport.html#ab4dd1d04047c5d1e157c7888e6d5e62e", null ]
];