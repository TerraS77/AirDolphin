var structbutton =
[
    [ "action", "structbutton.html#ac112694c1541cc57be96b83f17f1c623", null ],
    [ "center", "structbutton.html#a69e4ec4b284dd1363a7d78010ca9745e", null ],
    [ "CID", "structbutton.html#a1868866a0df445471a023b4c14919ca8", null ],
    [ "CSG", "structbutton.html#af1ecbbd2629c7d14a75b8d4a776af64d", null ],
    [ "selected", "structbutton.html#a9ee682957ef18956fbe33afe9b6222fa", null ],
    [ "text", "structbutton.html#a5633b1433389cec21ade3811bbe9ca5b", null ]
];