var structchain_item =
[
    [ "data", "structchain_item.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "index", "structchain_item.html#a750b5d744c39a06bfb13e6eb010e35d0", null ],
    [ "next", "structchain_item.html#ae2a62e969319cae7cdb3c358b1d0b453", null ],
    [ "previous", "structchain_item.html#a5f816f08150b590b5b087a1f583146ea", null ]
];