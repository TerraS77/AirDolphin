var structsimulation =
[
    [ "airport", "structsimulation.html#a9c679aa8f50895ef493c226310dd41c6", null ],
    [ "planeActors", "structsimulation.html#a7dafe48c0b482af1f3187d7f2a11c1eb", null ],
    [ "simulationSpeedInMs", "structsimulation.html#a21aed27382c21bf38c675ea0570cdb80", null ]
];